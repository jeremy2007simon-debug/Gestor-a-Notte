import { useState, useEffect, useRef } from "react";

const INITIAL_GROUPS = [
  { id:"bar",           name:"Bar",            icon:"🍺", color:"#C8854A" },
  { id:"alimentacion",  name:"Alimentación",   icon:"🥐", color:"#7B9E5B" },
  { id:"limpieza",      name:"Limpiezas",      icon:"🧹", color:"#5B8BB5" },
  { id:"otros",         name:"Otros",          icon:"📦", color:"#888"    },
];

const MONTHS = ["Enero","Febrero","Marzo","Abril","Mayo","Junio",
                "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];

function uid(){ return Math.random().toString(36).substr(2,9); }
function euro(n){ return Number(n||0).toLocaleString("es-ES",{style:"currency",currency:"EUR"}); }
function todayStr(){ return new Date().toISOString().split("T")[0]; }
async function toB64(file){ return new Promise((res,rej)=>{ const r=new FileReader(); r.onload=()=>res(r.result.split(",")[1]); r.onerror=rej; r.readAsDataURL(file); }); }

// ─── Root ────────────────────────────────────────────────────────────────────
export default function App() {
  const [groups,   setGroups]   = useState(INITIAL_GROUPS);
  // lineas: { id, proveedor, fecha, numero_factura, nombre, cantidad, unidad, precioUnit, importe, groupId }
  // (cada línea de factura es una entrada independiente)
  const [lineas,   setLineas]   = useState([]);
  const [view,     setView]     = useState("inicio");
  const [month,    setMonth]    = useState(new Date().getMonth());
  const [year,     setYear]     = useState(new Date().getFullYear());

  useEffect(()=>{ load("cf3_groups", setGroups); },[]);
  useEffect(()=>{ load("cf3_lineas", setLineas); },[]);
  useEffect(()=>{ save("cf3_groups", groups); },[groups]);
  useEffect(()=>{ save("cf3_lineas", lineas); },[lineas]);

  async function load(k,fn){ try{ const r=localStorage.getItem(k); if(r) fn(JSON.parse(r)); }catch{} }
  function save(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); }catch{} }

  function addLineas(nuevas){ setLineas(p=>[...p,...nuevas]); }
  function delLinea(id){ setLineas(p=>p.filter(l=>l.id!==id)); }
  function delFactura(proveedor, fecha, numero_factura){
    setLineas(p=>p.filter(l=>!(l.proveedor===proveedor&&l.fecha===fecha&&l.numero_factura===numero_factura)));
  }

  function monthLineas(){ return lineas.filter(l=>{ const d=new Date(l.fecha); return d.getMonth()===month&&d.getFullYear()===year; }); }

  // stock: agrupado por groupId → nombre → {totalQty, totalGasto, unidad}
  function buildStock(pool){
    const s={};
    (pool||lineas).forEach(l=>{
      if(!s[l.groupId]) s[l.groupId]={};
      const k=l.nombre?.trim();
      if(!k) return;
      if(!s[l.groupId][k]) s[l.groupId][k]={totalQty:0,totalGasto:0,unidad:l.unidad||"ud"};
      s[l.groupId][k].totalQty  +=Number(l.cantidad)||0;
      s[l.groupId][k].totalGasto+=Number(l.importe)||0;
    });
    return s;
  }

  // facturas únicas del mes (agrupadas por proveedor+fecha+numero)
  function monthFacturas(){
    const ml=monthLineas();
    const map={};
    ml.forEach(l=>{
      const key=`${l.proveedor}||${l.fecha}||${l.numero_factura}`;
      if(!map[key]) map[key]={proveedor:l.proveedor,fecha:l.fecha,numero_factura:l.numero_factura,total:0,lineas:[]};
      map[key].total+=Number(l.importe)||0;
      map[key].lineas.push(l);
    });
    return Object.values(map).sort((a,b)=>new Date(b.fecha)-new Date(a.fecha));
  }

  const nav=[
    {id:"inicio",   label:"Inicio",   icon:"🏠"},
    {id:"stock",    label:"Stock",    icon:"📦"},
    {id:"invoices", label:"Facturas", icon:"🧾"},
    {id:"resumen",  label:"Resumen",  icon:"📊"},
    {id:"grupos",   label:"Grupos",   icon:"🗂️"},
  ];

  return(
    <div style={{minHeight:"100vh",background:"#0e1a14",fontFamily:"'Palatino Linotype','Book Antiqua',Palatino,serif",color:"#e8f0e8"}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&display=swap');
        *{box-sizing:border-box}
        ::-webkit-scrollbar{width:5px}::-webkit-scrollbar-track{background:#0e1a14}::-webkit-scrollbar-thumb{background:#2a4a2a;border-radius:3px}
        input,select{outline:none}
        input[type=date]::-webkit-calendar-picker-indicator{filter:invert(0.6) sepia(1) saturate(2) hue-rotate(80deg)}
        .nb:hover{background:rgba(80,160,80,0.12)!important;color:#7bc47b!important}
        .card:hover{border-color:rgba(80,160,80,0.22)!important}
        .delbtn:hover{color:#e07070!important}
        .cc:hover{border-color:rgba(123,196,123,0.5)!important;background:rgba(123,196,123,0.06)!important}
      `}</style>

      <div style={{display:"flex",minHeight:"100vh"}}>
        {/* Sidebar */}
        <aside style={{width:190,background:"#091210",borderRight:"1px solid #1a2e1a",display:"flex",flexDirection:"column",padding:"22px 0",position:"sticky",top:0,height:"100vh",flexShrink:0}}>
          <div style={{padding:"0 18px 26px"}}>
            <div style={{fontSize:28,marginBottom:4}}>☕</div>
            <div style={{fontFamily:"'Playfair Display',Georgia,serif",fontSize:15,color:"#7bc47b",fontWeight:700,lineHeight:1.2}}>Gestión</div>
            <div style={{fontFamily:"'Playfair Display',Georgia,serif",fontSize:15,color:"#7bc47b",fontWeight:700}}>Cafetería</div>
            <div style={{fontSize:10,color:"rgba(232,240,232,0.22)",marginTop:4,letterSpacing:2}}>CONTROL DE GASTOS</div>
          </div>
          <nav style={{flex:1}}>
            {nav.map(n=>(
              <button key={n.id} className="nb" onClick={()=>setView(n.id)} style={{
                display:"block",width:"100%",textAlign:"left",
                background:view===n.id?"rgba(80,160,80,0.15)":"transparent",
                border:"none",borderLeft:view===n.id?"3px solid #7bc47b":"3px solid transparent",
                color:view===n.id?"#7bc47b":"rgba(232,240,232,0.48)",
                padding:"11px 18px",cursor:"pointer",fontFamily:"inherit",fontSize:14,transition:"all 0.15s",
              }}><span style={{marginRight:10}}>{n.icon}</span>{n.label}</button>
            ))}
          </nav>
          <div style={{padding:"14px 18px",fontSize:11,color:"rgba(232,240,232,0.18)",lineHeight:1.7}}>{MONTHS[month]}<br/>{year}</div>
        </aside>

        {/* Main */}
        <main style={{flex:1,padding:"32px 36px",overflow:"auto",maxWidth:900}}>
          <MonthBar month={month} year={year} setMonth={setMonth} setYear={setYear}/>
          {view==="inicio"   && <InicioView   groups={groups} lineas={lineas} month={month} year={year} setView={setView}/>}
          {view==="stock"    && <StockView    groups={groups} lineas={lineas} delLinea={delLinea} setView={setView}/>}
          {view==="invoices" && <InvoicesView groups={groups} facturas={monthFacturas()} addLineas={addLineas} delFactura={delFactura} setLineas={setLineas} setView={setView}/>}
          {view==="resumen"  && <ResumenView  groups={groups} facturas={monthFacturas()} monthStock={buildStock(monthLineas())} month={month} year={year}/>}
          {view==="grupos"   && <GruposView   groups={groups} setGroups={setGroups} lineas={lineas}/>}
        </main>
      </div>
    </div>
  );
}

// ─── MonthBar ─────────────────────────────────────────────────────────────────
function MonthBar({month,year,setMonth,setYear}){
  return(
    <div style={{display:"flex",gap:10,marginBottom:28}}>
      <select value={month} onChange={e=>setMonth(+e.target.value)} style={SS}>{MONTHS.map((m,i)=><option key={i} value={i}>{m}</option>)}</select>
      <select value={year}  onChange={e=>setYear(+e.target.value)}  style={SS}>{[2023,2024,2025,2026].map(y=><option key={y} value={y}>{y}</option>)}</select>
    </div>
  );
}

// ─── STOCK VIEW ───────────────────────────────────────────────────────────────
// ─── INICIO VIEW ─────────────────────────────────────────────────────────────
function InicioView({groups, lineas, month, year, setView}){
  const monthLineas = lineas.filter(l=>{ const d=new Date(l.fecha); return d.getMonth()===month&&d.getFullYear()===year; });
  const totalMes = monthLineas.reduce((s,l)=>s+Number(l.importe),0);
  const totalGlobal = lineas.reduce((s,l)=>s+Number(l.importe),0);
  const facturasMes = new Set(monthLineas.map(l=>`${l.proveedor}||${l.fecha}||${l.numero_factura}`)).size;
  const proveedoresMes = new Set(monthLineas.map(l=>l.proveedor).filter(Boolean)).size;
  const now = new Date();
  const hora = now.getHours();
  const saludo = hora<13?"Buenos días":hora<20?"Buenas tardes":"Buenas noches";

  const gastosPorGrupo = groups.map(g=>{
    const total = monthLineas.filter(l=>l.groupId===g.id).reduce((s,l)=>s+Number(l.importe),0);
    return {...g, total};
  }).filter(g=>g.total>0).sort((a,b)=>b.total-a.total);

  return(
    <div>
      {/* Hero bienvenida */}
      <div style={{
        background:"linear-gradient(135deg, #7c3a00 0%, #c8650a 40%, #e8900a 70%, #7c3a00 100%)",
        borderRadius:20,
        padding:"40px 36px",
        marginBottom:28,
        position:"relative",
        overflow:"hidden",
      }}>
        {/* Decorative circles */}
        <div style={{position:"absolute",top:-40,right:-40,width:200,height:200,borderRadius:"50%",background:"rgba(255,255,255,0.06)"}}/>
        <div style={{position:"absolute",bottom:-60,right:60,width:160,height:160,borderRadius:"50%",background:"rgba(255,255,255,0.04)"}}/>
        <div style={{position:"absolute",top:20,right:160,width:80,height:80,borderRadius:"50%",background:"rgba(255,255,255,0.05)"}}/>

        <div style={{fontSize:48,marginBottom:12}}>☕</div>
        <div style={{fontSize:13,color:"rgba(255,240,200,0.7)",letterSpacing:3,textTransform:"uppercase",marginBottom:8}}>
          {saludo}
        </div>
        <h1 style={{fontFamily:"'Playfair Display',Georgia,serif",fontSize:32,color:"#fff",fontWeight:700,margin:"0 0 6px",lineHeight:1.2}}>
          Bienvenido a su web<br/>de gestoría
        </h1>
        <p style={{fontSize:14,color:"rgba(255,240,200,0.7)",margin:"0 0 24px"}}>
          {MONTHS[month]} {year} — Panel de control
        </p>
        <button onClick={()=>setView("invoices")} style={{
          background:"rgba(0,0,0,0.25)",
          border:"2px solid rgba(255,255,255,0.4)",
          color:"#fff",
          padding:"10px 24px",
          borderRadius:10,
          cursor:"pointer",
          fontFamily:"inherit",
          fontSize:14,
          fontWeight:700,
          backdropFilter:"blur(8px)",
        }}>+ Registrar factura</button>
      </div>

      {/* KPIs */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))",gap:14,marginBottom:28}}>
        {[
          {label:"Gasto del mes", value:euro(totalMes), icon:"💶", bg:"linear-gradient(135deg,#1a3a1a,#0e2a0e)", accent:"#7bc47b"},
          {label:"Facturas",      value:facturasMes,    icon:"🧾", bg:"linear-gradient(135deg,#3a2a0a,#2a1a00)", accent:"#C8854A"},
          {label:"Proveedores",   value:proveedoresMes, icon:"🏢", bg:"linear-gradient(135deg,#0a1a3a,#001022)", accent:"#5B8BB5"},
          {label:"Total acumulado",value:euro(totalGlobal),icon:"📈",bg:"linear-gradient(135deg,#2a0a2a,#1a001a)",accent:"#B5855B"},
        ].map((k,i)=>(
          <div key={i} style={{background:k.bg,border:`1px solid ${k.accent}33`,borderRadius:14,padding:"18px 16px"}}>
            <div style={{fontSize:26,marginBottom:8}}>{k.icon}</div>
            <div style={{fontFamily:"'Playfair Display',Georgia,serif",fontSize:22,color:k.accent,fontWeight:700,marginBottom:4}}>{k.value}</div>
            <div style={{fontSize:11,color:"rgba(232,240,232,0.4)",textTransform:"uppercase",letterSpacing:1}}>{k.label}</div>
          </div>
        ))}
      </div>

      {/* Gasto por grupo este mes */}
      {gastosPorGrupo.length > 0 && (
        <div>
          <h2 style={{fontFamily:"'Playfair Display',Georgia,serif",fontSize:18,color:"#C8854A",fontWeight:400,marginBottom:16}}>
            Distribución del gasto — {MONTHS[month]}
          </h2>
          <div style={{display:"grid",gap:10}}>
            {gastosPorGrupo.map(g=>{
              const pct = totalMes>0?(g.total/totalMes)*100:0;
              return(
                <div key={g.id} onClick={()=>setView("stock")} style={{
                  background:"#111e14",border:`1px solid ${g.color}33`,borderRadius:12,
                  padding:"14px 16px",cursor:"pointer",transition:"border-color 0.15s",
                }}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:8,alignItems:"center"}}>
                    <div style={{display:"flex",alignItems:"center",gap:8}}>
                      <span style={{fontSize:18}}>{g.icon}</span>
                      <span style={{fontWeight:600,fontSize:15}}>{g.name}</span>
                    </div>
                    <span style={{color:g.color,fontWeight:700,fontSize:15}}>{euro(g.total)}</span>
                  </div>
                  <div style={{height:7,background:"rgba(255,255,255,0.06)",borderRadius:4,overflow:"hidden"}}>
                    <div style={{width:`${pct}%`,height:"100%",background:g.color,borderRadius:4,transition:"width 0.6s"}}/>
                  </div>
                  <div style={{fontSize:11,color:"rgba(232,240,232,0.3)",marginTop:5}}>{pct.toFixed(1)}% del total mensual</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {gastosPorGrupo.length===0 && (
        <div style={{textAlign:"center",padding:"40px 20px",background:"#111e14",borderRadius:16,border:"1px dashed rgba(200,133,74,0.3)"}}>
          <div style={{fontSize:48,marginBottom:12}}>📋</div>
          <div style={{color:"rgba(232,240,232,0.4)",marginBottom:16}}>No hay datos para este mes todavía</div>
          <button onClick={()=>setView("invoices")} style={BP}>Añadir primera factura</button>
        </div>
      )}
    </div>
  );
}


function StockView({groups, lineas, delLinea, setView}){
  const [scope, setScope] = useState("total");
  const [editStock, setEditStock] = useState(null);

  const now = new Date();
  const pool = scope === "mes"
    ? lineas.filter(l=>{ const d=new Date(l.fecha); return d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear(); })
    : lineas;

  function buildDetalle(arr) {
    const g = {};
    const displayNames = {};
    arr.forEach(l => {
      const gid = l.groupId || "otros";
      const raw = l.nombre && l.nombre.trim();
      if (!raw) return;
      const key = raw.toLowerCase().replace(/  */g," ");
      const dk = gid+"|"+key;
      if (!displayNames[dk]) displayNames[dk] = raw;
      const nombre = displayNames[dk];
      if (!g[gid]) g[gid] = {};
      if (!g[gid][nombre]) g[gid][nombre] = {};
      const prov = (l.proveedor && l.proveedor.trim()) || "Desconocido";
      if (!g[gid][nombre][prov]) g[gid][nombre][prov] = { cantidad:0, importe:0, precioUnit:Number(l.precioUnit)||0, unidad:l.unidad||"ud", ids:[] };
      g[gid][nombre][prov].cantidad += Number(l.cantidad)||0;
      g[gid][nombre][prov].importe  += Number(l.importe)||0;
      g[gid][nombre][prov].ids.push(l.id);
      if (Number(l.precioUnit) > 0) g[gid][nombre][prov].precioUnit = Number(l.precioUnit);
    });
    return g;
  }

  const detalle = buildDetalle(pool);

  // cross-group price comparison
  const globalMinMax = {};
  groups.forEach(g => {
    const prods = detalle[g.id] || {};
    Object.entries(prods).forEach(([nombre, provs]) => {
      const key = nombre.toLowerCase().replace(/  */g," ");
      if (!globalMinMax[key]) globalMinMax[key] = {};
      Object.entries(provs).forEach(([prov, e]) => {
        globalMinMax[key][prov] = e.precioUnit;
      });
    });
  });
  const globalRange = {};
  Object.entries(globalMinMax).forEach(([key, provMap]) => {
    const vals = Object.values(provMap);
    if (vals.length > 1) {
      globalRange[key] = { min: Math.min(...vals), max: Math.max(...vals) };
    }
  });

  const totalGasto = groups.reduce((s,g)=>
    s+Object.values(detalle[g.id]||{}).reduce((s2,provs)=>
      s2+Object.values(provs).reduce((s3,e)=>s3+e.importe,0),0),0);
  const hasData = groups.some(g=>Object.keys(detalle[g.id]||{}).length>0);

  function doDelete(ids) {
    ids.forEach(id => delLinea(id));
    setEditStock(null);
  }

  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6,flexWrap:"wrap",gap:12}}>
        <div>
          <h1 style={H1}>Mercancía Comprada</h1>
          <p style={{fontSize:13,color:"rgba(232,240,232,0.32)",margin:"4px 0 0"}}>Detalle por producto y proveedor. Verde = más barato, Rojo = más caro.</p>
        </div>
        <button onClick={()=>setView("invoices")} style={BP}>+ Añadir factura</button>
      </div>

      <div style={{display:"flex",gap:8,margin:"20px 0 24px",alignItems:"center"}}>
        {["total","mes"].map(s=>(
          <button key={s} onClick={()=>setScope(s)} style={{
            background:scope===s?"rgba(123,196,123,0.15)":"transparent",
            border:"1px solid "+(scope===s?"rgba(123,196,123,0.4)":"rgba(255,255,255,0.08)"),
            color:scope===s?"#7bc47b":"rgba(232,240,232,0.38)",
            padding:"6px 16px",borderRadius:20,cursor:"pointer",fontFamily:"inherit",fontSize:13,transition:"all 0.15s",
          }}>{s==="total"?"Acumulado total":"Este mes"}</button>
        ))}
        {hasData && <span style={{marginLeft:"auto",fontSize:13,color:"rgba(232,240,232,0.35)"}}>Total: <strong style={{color:"#7bc47b"}}>{euro(totalGasto)}</strong></span>}
      </div>

      {!hasData && <Empty text="Aún no hay datos. Añade tu primera factura."/>}

      {groups.map(g=>{
        const prods = detalle[g.id] || {};
        const prodNames = Object.keys(prods);
        if (!prodNames.length) return null;
        const gTotal = prodNames.reduce((s,n)=>s+Object.values(prods[n]).reduce((s2,e)=>s2+e.importe,0),0);
        return (
          <div key={g.id} style={{marginBottom:32}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:14,paddingBottom:10,borderBottom:"2px solid "+g.color+"44"}}>
              <span style={{fontSize:22}}>{g.icon}</span>
              <span style={{fontFamily:"'Playfair Display',Georgia,serif",fontSize:18,color:g.color,fontWeight:600}}>{g.name}</span>
              <span style={{marginLeft:"auto",color:g.color,fontWeight:700,fontSize:16}}>{euro(gTotal)}</span>
            </div>

            <div style={{display:"grid",gridTemplateColumns:"1fr 90px 90px 90px 38px",gap:6,padding:"6px 14px",marginBottom:4}}>
              {["Producto / Empresa","P. Unit.","Cant.","Total",""].map((h,i)=>(
                <div key={i} style={{fontSize:10,color:"rgba(232,240,232,0.3)",textTransform:"uppercase",letterSpacing:1,textAlign:i>0?"right":"left"}}>{h}</div>
              ))}
            </div>

            {prodNames.map(nombre=>{
              const provs = prods[nombre];
              const provList = Object.entries(provs);
              const nkey = nombre.toLowerCase().replace(/  */g," ");
              const range = globalRange[nkey];
              const minP = range ? range.min : null;
              const maxP = range ? range.max : null;

              return (
                <div key={nombre} style={{marginBottom:8,background:"#111e14",borderRadius:10,overflow:"hidden",border:"1px solid "+g.color+"33"}}>
                  <div style={{padding:"10px 14px 8px",fontWeight:700,fontSize:15,color:"#e8f0e8",borderBottom:"1px solid rgba(255,255,255,0.05)"}}>
                    {nombre}
                    {provList.length>1 && <span style={{fontSize:11,color:"rgba(232,240,232,0.35)",fontWeight:400,marginLeft:10}}>· {provList.length} proveedores</span>}
                  </div>

                  {provList.map(([prov, e])=>{
                    const isCheap = minP !== null && e.precioUnit === minP && minP !== maxP;
                    const isExp   = maxP !== null && e.precioUnit === maxP && minP !== maxP;
                    const rowBg   = isCheap ? "rgba(50,160,50,0.1)" : isExp ? "rgba(180,50,50,0.1)" : "transparent";
                    const priceCol= isCheap ? "#6fe87b" : isExp ? "#ff7070" : "rgba(232,240,232,0.7)";
                    return (
                      <div key={prov} style={{display:"grid",gridTemplateColumns:"1fr 90px 90px 90px 38px",gap:6,padding:"9px 14px",background:rowBg,alignItems:"center",borderBottom:"1px solid rgba(255,255,255,0.03)"}}>
                        <div style={{display:"flex",flexDirection:"column",gap:4}}>
                          <span style={{fontSize:12,color:"rgba(232,240,232,0.55)"}}>🏢 {prov}</span>
                          {isCheap && <span style={{fontSize:10,padding:"1px 7px",borderRadius:20,background:"rgba(50,180,50,0.25)",color:"#6fe87b",fontWeight:700,border:"1px solid rgba(50,200,50,0.35)",alignSelf:"flex-start"}}>✓ más barato</span>}
                          {isExp   && <span style={{fontSize:10,padding:"1px 7px",borderRadius:20,background:"rgba(200,50,50,0.25)",color:"#ff8080",fontWeight:700,border:"1px solid rgba(200,50,50,0.35)",alignSelf:"flex-start"}}>↑ más caro</span>}
                        </div>
                        <div style={{textAlign:"right",fontWeight:700,fontSize:13,color:priceCol,padding:"2px 5px",borderRadius:5,background:isCheap?"rgba(50,160,50,0.15)":isExp?"rgba(180,50,50,0.15)":"transparent"}}>{euro(e.precioUnit)}</div>
                        <div style={{textAlign:"right",fontSize:13,color:"rgba(232,240,232,0.6)"}}>{Number(e.cantidad.toFixed(2))} <span style={{fontSize:10,color:"rgba(232,240,232,0.3)"}}>{e.unidad}</span></div>
                        <div style={{textAlign:"right",fontWeight:600,fontSize:13,color:g.color}}>{euro(e.importe)}</div>
                        <button onClick={(ev)=>{ ev.stopPropagation(); setEditStock({ids:[...e.ids], label:nombre+" — "+prov, nombre, prov, groupId:g.id}); }} style={{background:"rgba(90,140,200,0.2)",border:"1px solid rgba(90,140,200,0.4)",borderRadius:7,color:"#7aabdd",cursor:"pointer",fontSize:14,padding:"5px",display:"flex",alignItems:"center",justifyContent:"center",width:34,height:34,flexShrink:0}}>✏️</button>
                      </div>
                    );
                  })}

                  {provList.length>1 && (
                    <div style={{display:"grid",gridTemplateColumns:"1fr 90px 90px 90px 38px",gap:6,padding:"7px 14px",background:"rgba(255,255,255,0.03)",borderTop:"1px solid rgba(255,255,255,0.06)"}}>
                      <div style={{fontSize:11,color:"rgba(232,240,232,0.3)"}}>Subtotal {nombre}</div>
                      <div/>
                      <div style={{textAlign:"right",fontSize:12,color:"rgba(232,240,232,0.4)"}}>{Number(provList.reduce((s,[,e])=>s+e.cantidad,0).toFixed(2))}</div>
                      <div style={{textAlign:"right",fontWeight:700,color:g.color}}>{euro(provList.reduce((s,[,e])=>s+e.importe,0))}</div>
                      <div/>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        );
      })}

      {editStock && (
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.75)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:9999,padding:24}}>
          <div style={{background:"#0e1a14",border:"1px solid rgba(90,140,200,0.3)",borderRadius:16,padding:28,maxWidth:360,width:"100%"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
              <h3 style={{fontFamily:"'Playfair Display',Georgia,serif",color:"#7bc47b",fontSize:18,fontWeight:400,margin:0}}>Detalle del registro</h3>
              <button onClick={()=>setEditStock(null)} style={{background:"none",border:"none",color:"rgba(232,240,232,0.4)",cursor:"pointer",fontSize:22,padding:0}}>×</button>
            </div>
            <div style={{marginBottom:8}}>
              <div style={{fontSize:11,color:"rgba(232,240,232,0.4)",textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>Producto</div>
              <div style={{fontWeight:700,fontSize:16,color:"#e8f0e8"}}>{editStock.nombre}</div>
            </div>
            <div style={{marginBottom:20}}>
              <div style={{fontSize:11,color:"rgba(232,240,232,0.4)",textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>Proveedor</div>
              <div style={{fontSize:14,color:"rgba(232,240,232,0.7)"}}>🏢 {editStock.prov}</div>
            </div>
            <div style={{display:"flex",gap:10,justifyContent:"space-between",alignItems:"center",paddingTop:16,borderTop:"1px solid rgba(255,255,255,0.06)"}}>
              <button onClick={()=>setEditStock(null)} style={{background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:8,color:"rgba(232,240,232,0.5)",padding:"10px 18px",cursor:"pointer",fontFamily:"inherit",fontSize:14}}>Cerrar</button>
              <button onClick={()=>{ if(editStock.ids.length>0){ editStock.ids.forEach(id=>delLinea(id)); setEditStock(null); } }} style={{background:"rgba(200,60,60,0.2)",border:"1px solid rgba(200,60,60,0.4)",borderRadius:8,color:"#e07070",padding:"10px 18px",cursor:"pointer",fontFamily:"inherit",fontSize:14,fontWeight:700}}>🗑 Eliminar registro</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}


// ─── INVOICES VIEW ────────────────────────────────────────────────────────────
function InvoicesView({groups,facturas,addLineas,delFactura,setLineas,setView}){
  const [mode,setMode]=useState("list");
  const [pending,setPending]=useState(null); // array of lineas pendientes de confirmar
  const [aiLoading,setAiLoading]=useState(false);
  const [aiError,setAiError]=useState("");
  const [manualInv,setManualInv]=useState(null);
  const [editInv,setEditInv]=useState(null);
  const fileRef=useRef();
  const cameraRef=useRef();

  function saveEdit(inv){
    // delete original lines by their ids, then add updated ones
    const oldIds = new Set(inv.lineas.map(l=>l.id));
    setLineas(p => {
      const sinViejas = p.filter(l => !oldIds.has(l.id));
      const nuevas = inv.lineas.map(l=>({...l, proveedor:inv.proveedor, fecha:inv.fecha, numero_factura:inv.numero_factura}));
      return [...sinViejas, ...nuevas];
    });
    setEditInv(null);
  }

  async function scanFile(file){
    setAiLoading(true); setAiError("");
    try{
      const b64=await toB64(file);
      const isPdf=file.type==="application/pdf";
      const block=isPdf
        ?{type:"document",source:{type:"base64",media_type:"application/pdf",data:b64}}
        :{type:"image",source:{type:"base64",media_type:file.type||"image/jpeg",data:b64}};

      const groupList=groups.map(g=>`"${g.id}": ${g.name} (${g.icon})`).join(", ");

      const resp=await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          model:"claude-sonnet-4-20250514",max_tokens:2000,
          messages:[{role:"user",content:[block,{type:"text",
            text:`Analiza esta factura de cafetería. Para CADA producto/línea de la factura, asígnale el grupo más adecuado de esta lista:
${groupList}

Responde SOLO con este JSON sin markdown ni explicación:
{
  "proveedor": "nombre empresa",
  "fecha": "YYYY-MM-DD",
  "numero_factura": "número o null",
  "lineas": [
    {
      "nombre": "nombre exacto del producto",
      "cantidad": número,
      "unidad": "kg|L|ud|caja|botella|sobre|paquete|etc",
      "precioUnit": número,
      "importe": número,
      "groupId": "id del grupo más adecuado de la lista",
      "grupoNombre": "nombre del grupo"
    }
  ]
}`
          }]}]
        })
      });
      const data=await resp.json();
      const text=data.content.map(i=>i.text||"").join("");
      const parsed=JSON.parse(text.replace(/```json|```/g,"").trim());
      const lineasConId=parsed.lineas.map(l=>({
        ...l,
        id:uid(),
        proveedor:parsed.proveedor||"",
        fecha:parsed.fecha||todayStr(),
        numero_factura:parsed.numero_factura||"",
        groupId: groups.find(g=>g.id===l.groupId)?l.groupId:"otros",
      }));
      setPending({proveedor:parsed.proveedor||"",fecha:parsed.fecha||todayStr(),numero_factura:parsed.numero_factura||"",lineas:lineasConId});
      setMode("confirm");
    }catch(e){
      setAiError("No se pudo leer la factura. Prueba el formulario manual.");
    }
    setAiLoading(false);
  }

  function save(){
    addLineas(pending.lineas);
    setPending(null); setMode("list");
  }

  function totalPending(){ return pending?.lineas.reduce((s,l)=>s+Number(l.importe),0)||0; }

  function updatePendingLinea(i,k,v){
    setPending(p=>({...p,lineas:p.lineas.map((l,idx)=>idx===i?{...l,[k]:v}:l)}));
  }
  function removePendingLinea(i){
    setPending(p=>({...p,lineas:p.lineas.filter((_,idx)=>idx!==i)}));
  }

  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22,flexWrap:"wrap",gap:12}}>
        <h1 style={H1}>Facturas</h1>
        {mode==="list"&&<button onClick={()=>setMode("choose")} style={BP}>+ Nueva factura</button>}
        {mode!=="list"&&<button onClick={()=>{setMode("list");setPending(null);setManualInv(null);setAiError("");}} style={BS}>← Volver</button>}
      </div>

      {/* Choose */}
      {mode==="choose"&&(
        <div>
          <div style={{background:"rgba(123,196,123,0.07)",border:"1px solid rgba(123,196,123,0.2)",borderRadius:12,padding:"12px 16px",marginBottom:20,fontSize:13,color:"rgba(232,240,232,0.55)",lineHeight:1.6}}>
            💡 <strong style={{color:"#7bc47b"}}>Consejo:</strong> En el iPhone, abre la foto del ticket → pulsa el icono de texto (<strong>Live Text</strong>) → Seleccionar todo → Copiar. Luego pégalo en "Pegar texto".
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,maxWidth:460}}>
            <div className="cc" onClick={()=>setMode("texto")} style={{background:"#111e14",border:"2px solid rgba(123,196,123,0.3)",borderRadius:14,padding:24,cursor:"pointer",textAlign:"center",transition:"all 0.15s"}}>
              <div style={{fontSize:36,marginBottom:10}}>📋</div>
              <div style={{fontWeight:700,color:"#7bc47b",marginBottom:6}}>Pegar texto</div>
              <div style={{fontSize:12,color:"rgba(232,240,232,0.38)",lineHeight:1.5}}>Pega el texto del ticket y la IA lo interpreta</div>
            </div>
            <div className="cc" onClick={()=>{setManualInv({proveedor:"",fecha:todayStr(),numero_factura:"",lineas:[{id:uid(),nombre:"",cantidad:1,unidad:"ud",precioUnit:0,importe:0,groupId:groups[0]?.id||"otros"}]});setMode("manual");}} style={{background:"#111e14",border:"1px solid #1a2e1a",borderRadius:14,padding:24,cursor:"pointer",textAlign:"center",transition:"all 0.15s"}}>
              <div style={{fontSize:36,marginBottom:10}}>✏️</div>
              <div style={{fontWeight:700,color:"#7bc47b",marginBottom:6}}>Manual</div>
              <div style={{fontSize:12,color:"rgba(232,240,232,0.38)",lineHeight:1.5}}>Rellena el formulario a mano</div>
            </div>
          </div>
        </div>
      )}

      {/* Scan */}
{mode==="camera"&&(
        <CameraCapture onCapture={(file)=>{ setMode("scan"); scanFile(file); }} onBack={()=>setMode("choose")} aiLoading={aiLoading}/>
      )}



            {mode==="scan"&&(
        <div>
          <div
            style={{border:"2px dashed rgba(123,196,123,0.3)",borderRadius:14,padding:52,textAlign:"center",cursor:"pointer",maxWidth:440,background:"rgba(0,0,0,0.1)"}}
            onClick={()=>fileRef.current.click()}
            onDragOver={e=>e.preventDefault()}
            onDrop={e=>{e.preventDefault();const f=e.dataTransfer.files[0];if(f)scanFile(f);}}>
            {aiLoading
              ?<><div style={{fontSize:40,marginBottom:12}}>⏳</div><div style={{color:"#7bc47b"}}>Analizando y clasificando productos…</div><div style={{fontSize:12,color:"rgba(232,240,232,0.3)",marginTop:8}}>La IA asignará cada producto al grupo correcto</div></>
              :<><div style={{fontSize:46,marginBottom:12}}>📄</div><div style={{color:"#7bc47b",marginBottom:6}}>Arrastra o haz clic para subir</div><div style={{fontSize:12,color:"rgba(232,240,232,0.3)"}}>JPG · PNG · PDF</div></>
            }
            <input ref={fileRef} type="file" accept="image/*,.pdf" style={{display:"none"}} onChange={e=>{if(e.target.files[0])scanFile(e.target.files[0]);}}/>
          <input ref={cameraRef} type="file" accept="image/*" capture="environment" style={{display:"none"}} onChange={e=>{if(e.target.files[0]){ setMode("scan"); scanFile(e.target.files[0]); }}}/>
          <input ref={cameraRef} type="file" accept="image/*" capture="environment" style={{display:"none"}} onChange={e=>{if(e.target.files[0]){ setMode("scan"); scanFile(e.target.files[0]); }}}/>
          <input ref={cameraRef} type="file" accept="image/*" capture="environment" style={{display:"none"}} onChange={e=>{if(e.target.files[0]){ setMode("scan"); scanFile(e.target.files[0]); }}}/>
          </div>
          {aiError&&<div style={{color:"#e07070",marginTop:14,fontSize:13}}>{aiError}</div>}
          <button onClick={()=>{setManualInv({proveedor:"",fecha:todayStr(),numero_factura:"",lineas:[{id:uid(),nombre:"",cantidad:1,unidad:"ud",precioUnit:0,importe:0,groupId:groups[0]?.id||"otros"}]});setMode("manual");}} style={{...BS,marginTop:16,fontSize:13}}>Ir a manual</button>
        </div>
      )}

      {/* Confirm AI result */}
        {mode==="texto"&&(
        <TextoPaste groups={groups} aiLoading={aiLoading} setAiLoading={setAiLoading} aiError={aiError} setAiError={setAiError}
          onResult={(parsed)=>{ setPending(parsed); setMode("confirm"); }}
          onBack={()=>setMode("choose")}/>
      )}

          {mode==="confirm"&&pending&&(
        <div style={{maxWidth:700}}>
          <div style={{background:"rgba(123,196,123,0.07)",border:"1px solid rgba(123,196,123,0.2)",borderRadius:12,padding:"14px 18px",marginBottom:22}}>
            <div style={{fontWeight:700,color:"#7bc47b",marginBottom:4}}>✅ La IA ha clasificado {pending.lineas.length} producto{pending.lineas.length!==1?"s":""}</div>
            <div style={{fontSize:13,color:"rgba(232,240,232,0.5)"}}>Revisa los grupos asignados. Puedes cambiarlos antes de guardar.</div>
          </div>

          {/* Invoice header */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:12,marginBottom:22}}>
            <div>
              <label style={LB}>Proveedor</label>
              <input value={pending.proveedor} onChange={e=>setPending(p=>({...p,proveedor:e.target.value}))} style={IS}/>
            </div>
            <div>
              <label style={LB}>Fecha</label>
              <input type="date" value={pending.fecha} onChange={e=>setPending(p=>({...p,fecha:e.target.value}))} style={IS}/>
            </div>
            <div>
              <label style={LB}>Nº Factura</label>
              <input value={pending.numero_factura||""} onChange={e=>setPending(p=>({...p,numero_factura:e.target.value}))} style={IS} placeholder="opcional"/>
            </div>
          </div>

          {/* Lines */}
          <div style={{marginBottom:20}}>
            <div style={{display:"grid",gridTemplateColumns:"2fr 70px 55px 80px 90px 140px 28px",gap:6,marginBottom:8}}>
              {["Producto","Cant.","Unid.","P.Unit.","Importe","Grupo",""].map((h,i)=>(
                <div key={i} style={{fontSize:10,color:"rgba(232,240,232,0.3)",textTransform:"uppercase",letterSpacing:1}}>{h}</div>
              ))}
            </div>
            {pending.lineas.map((l,i)=>{
              const g=groups.find(g=>g.id===l.groupId);
              return(
                <div key={l.id} style={{display:"grid",gridTemplateColumns:"2fr 70px 55px 80px 90px 140px 28px",gap:6,marginBottom:8,alignItems:"center",background:"#111e14",borderRadius:10,padding:"10px 12px",border:`1px solid ${g?.color||"#1a2e1a"}33`}}>
                  <input value={l.nombre} onChange={e=>updatePendingLinea(i,"nombre",e.target.value)} style={{...IS,fontSize:13}}/>
                  <input type="number" value={l.cantidad} onChange={e=>updatePendingLinea(i,"cantidad",e.target.value)} style={{...IS,fontSize:13}}/>
                  <input value={l.unidad} onChange={e=>updatePendingLinea(i,"unidad",e.target.value)} style={{...IS,fontSize:13}}/>
                  <input type="number" step="0.01" value={l.precioUnit} onChange={e=>updatePendingLinea(i,"precioUnit",e.target.value)} style={{...IS,fontSize:13}}/>
                  <input type="number" step="0.01" value={l.importe} onChange={e=>updatePendingLinea(i,"importe",e.target.value)} style={{...IS,fontSize:13}}/>
                  <select value={l.groupId} onChange={e=>updatePendingLinea(i,"groupId",e.target.value)} style={{...IS,fontSize:12,background:`${g?.color||"#1a2e1a"}22`}}>
                    {groups.map(g=><option key={g.id} value={g.id}>{g.icon} {g.name}</option>)}
                  </select>
                  <button onClick={()=>removePendingLinea(i)} style={{background:"none",border:"none",color:"rgba(232,240,232,0.25)",cursor:"pointer",fontSize:18,padding:0}}>×</button>
                </div>
              );
            })}
          </div>

          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:12}}>
            <div style={{fontSize:16,color:"rgba(232,240,232,0.5)"}}>Total: <strong style={{color:"#7bc47b",fontSize:18}}>{euro(totalPending())}</strong></div>
            <div style={{display:"flex",gap:10}}>
              <button onClick={()=>setMode("scan")} style={BS}>Volver</button>
              <button onClick={save} disabled={pending.lineas.length===0||!pending.proveedor} style={BP}>Guardar y actualizar stock</button>
            </div>
          </div>
        </div>
      )}

      {/* Manual form */}
      {mode==="manual"&&manualInv&&(
        <ManualForm
          inv={manualInv} setInv={setManualInv} groups={groups}
          onSave={()=>{
            const lineasConMeta=manualInv.lineas.map(l=>({...l,id:uid(),proveedor:manualInv.proveedor,fecha:manualInv.fecha,numero_factura:manualInv.numero_factura}));
            addLineas(lineasConMeta);
            setManualInv(null);setMode("list");
          }}
          onBack={()=>setMode("choose")}
        />
      )}

      {/* Edit modal */}
      {editInv && (
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.75)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:999,padding:20}}>
          <div style={{background:"#0e1a14",border:"1px solid rgba(123,196,123,0.25)",borderRadius:16,padding:28,width:"100%",maxWidth:660,maxHeight:"90vh",overflow:"auto"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20}}>
              <h2 style={{fontFamily:"'Playfair Display',Georgia,serif",color:"#7bc47b",fontSize:20,fontWeight:400,margin:0}}>Editar factura</h2>
              <button onClick={()=>setEditInv(null)} style={{background:"none",border:"none",color:"rgba(232,240,232,0.4)",cursor:"pointer",fontSize:22,padding:0}}>×</button>
            </div>
            <ManualForm inv={editInv} setInv={setEditInv} groups={groups} onSave={()=>saveEdit(editInv)} onBack={()=>setEditInv(null)}/>
            <div style={{marginTop:24,paddingTop:16,borderTop:"1px solid rgba(255,255,255,0.07)"}}>
              <button onClick={()=>{ delFactura(editInv.proveedor,editInv.fecha,editInv.numero_factura); setEditInv(null); }} style={{background:"rgba(200,60,60,0.15)",border:"1px solid rgba(200,60,60,0.35)",borderRadius:8,color:"#e07070",padding:"11px 18px",cursor:"pointer",fontFamily:"inherit",fontSize:14,fontWeight:600,width:"100%"}}>🗑 Eliminar esta factura</button>
            </div>
          </div>
        </div>
      )}

      {/* List */}
      {mode==="list"&&(
        facturas.length===0
          ?<Empty text="No hay facturas este mes"/>
          :<div style={{display:"grid",gap:10}}>
            {facturas.map((f,fi)=>{
              // group badges
              const usedGroups=[...new Set(f.lineas.map(l=>l.groupId))].map(gid=>groups.find(g=>g.id===gid)).filter(Boolean);
              return(
                <div key={fi} className="card" style={{background:"#111e14",border:"1px solid #1a2e1a",borderRadius:12,padding:"14px 18px",transition:"border-color 0.15s"}}>
                  <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:f.lineas.length?10:0}}>
                    <div style={{flex:1}}>
                      <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:6}}>
                        <div>
                          <div style={{fontWeight:700,fontSize:15,marginBottom:2}}>
                            {f.lineas.length===1 ? f.lineas[0].nombre : f.lineas.length>1 ? `${f.lineas[0].nombre} y ${f.lineas.length-1} más` : "Sin productos"}
                          </div>
                          <div style={{fontSize:12,color:"rgba(232,240,232,0.45)"}}>🏢 {f.proveedor||"Sin nombre"}</div>
                        </div>
                        <span style={{color:"#7bc47b",fontWeight:700,fontSize:15}}>{euro(f.total)}</span>
                      </div>
                      <div style={{fontSize:12,color:"rgba(232,240,232,0.35)",marginTop:4}}>
                        {f.fecha}{f.numero_factura?` · Nº ${f.numero_factura}`:""} · {f.lineas.length} producto{f.lineas.length!==1?"s":""}
                      </div>
                      {usedGroups.length>0&&(
                        <div style={{display:"flex",gap:6,marginTop:7,flexWrap:"wrap"}}>
                          {usedGroups.map(g=>(
                            <span key={g.id} style={{fontSize:11,background:`${g.color||"#888"}22`,border:`1px solid ${g.color||"#888"}44`,padding:"2px 8px",borderRadius:20,color:g.color||"#888"}}>
                              {g.icon} {g.name}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                    <button onClick={()=>{
                        const inv = facturas.find(x=>x.proveedor===f.proveedor&&x.fecha===f.fecha&&x.numero_factura===f.numero_factura);
                        if(inv) setEditInv({...inv});
                      }} style={{background:"rgba(90,140,200,0.15)",border:"1px solid rgba(90,140,200,0.3)",borderRadius:8,color:"#7aabdd",cursor:"pointer",fontSize:15,padding:"7px 10px",transition:"all 0.15s",minWidth:38,minHeight:38,display:"flex",alignItems:"center",justifyContent:"center"}} title="Editar">✏️</button>
                  </div>
                  {f.lineas.length>0&&(
                    <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
                      {f.lineas.slice(0,5).map((l,i)=>{
                        const g=groups.find(g=>g.id===l.groupId);
                        return <span key={i} style={{fontSize:11,background:"rgba(255,255,255,0.04)",padding:"2px 9px",borderRadius:20,color:"rgba(232,240,232,0.45)",borderLeft:`2px solid ${g?.color||"#888"}`}}>{l.nombre} {l.cantidad}{l.unidad}</span>;
                      })}
                      {f.lineas.length>5&&<span style={{fontSize:11,color:"rgba(232,240,232,0.28)"}}>+{f.lineas.length-5} más</span>}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
      )}
    </div>
  );
}

// ─── NombreInput: componente aislado para evitar pérdida de foco ──────────────
function NombreInput({ value, lineaId, groups, onCommit, onGroupDetected }) {
  const [local, setLocal] = useState(value);
  const [detecting, setDetecting] = useState(false);
  const debounceRef = useRef(null);

  useEffect(() => { setLocal(value); }, [value]);

  async function detectGroup(nombre) {
    if (!nombre || nombre.trim().length < 3) return;
    const groupList = groups.map(g => `${g.id}: ${g.name}`).join(", ");
    setDetecting(true);
    try {
      const resp = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST", headers: { "Content-Type": "application/json", "x-api-key": process.env.REACT_APP_ANTHROPIC_KEY, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514", max_tokens: 50,
          messages: [{ role: "user", content: `Para una cafetería/bar, clasifica el producto "${nombre}" en uno de estos grupos: ${groupList}. Bar=bebidas alcohólicas/café/refrescos/copas. Alimentación=comida/ingredientes. Limpiezas=productos limpieza. Otros=resto. Responde SOLO con el id del grupo, sin más texto.` }]
        })
      });
      const data = await resp.json();
      const raw = data.content?.[0]?.text?.trim().toLowerCase() || "";
      const match = groups.find(g => raw.includes(g.id));
      if (match) onGroupDetected(lineaId, match.id);
    } catch {}
    setDetecting(false);
  }

  function handleChange(e) {
    const val = e.target.value;
    setLocal(val);
    onCommit(val);
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => detectGroup(val), 800);
  }

  return (
    <div style={{ position: "relative" }}>
      <div style={{ fontSize: 10, color: "rgba(232,240,232,0.3)", textTransform: "uppercase", letterSpacing: 1, marginBottom: 5 }}>Producto</div>
      <input
        value={local}
        onChange={handleChange}
        placeholder="Ej: Café molido"
        style={{ width:"100%", background:"rgba(255,255,255,0.07)", border:"1px solid rgba(255,255,255,0.2)", color:"#e8f0e8", padding:"12px 14px", borderRadius:8, fontFamily:"inherit", fontSize:16, fontWeight:700, paddingRight: detecting ? "140px" : "14px", boxSizing:"border-box", outline:"none" }}
      />
      {detecting && <span style={{ position:"absolute", right:12, bottom:13, fontSize:12, color:"rgba(232,240,232,0.4)" }}>⏳ detectando…</span>}
    </div>
  );
}

// ─── Manual Form ──────────────────────────────────────────────────────────────
function ManualForm({inv,setInv,groups,onSave,onBack}){
  function setField(k,v){setInv(p=>({...p,[k]:v}));}
  function setL(i,k,v){setInv(p=>({...p,lineas:p.lineas.map((l,idx)=>idx===i?{...l,[k]:v}:l)}));}
  function addL(){setInv(p=>({...p,lineas:[...p.lineas,{id:uid(),nombre:"",cantidad:1,unidad:"ud",precioUnit:0,importe:0,groupId:groups[0]?.id||"otros"}]}));}
  function remL(i){setInv(p=>({...p,lineas:p.lineas.filter((_,idx)=>idx!==i)}));}

  function handleGroupDetected(lineaId, groupId){
    setInv(p=>({...p,lineas:p.lineas.map(l=>l.id===lineaId?{...l,groupId}:l)}));
  }

  return(
    <div style={{maxWidth:680}}>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:12,marginBottom:18}}>
        <div><label style={LB}>Proveedor</label><input value={inv.proveedor} onChange={e=>setField("proveedor",e.target.value)} style={IS} placeholder="Empresa"/></div>
        <div><label style={LB}>Fecha</label><input type="date" value={inv.fecha} onChange={e=>setField("fecha",e.target.value)} style={IS}/></div>
        <div><label style={LB}>Nº Factura</label><input value={inv.numero_factura} onChange={e=>setField("numero_factura",e.target.value)} style={IS} placeholder="opcional"/></div>
      </div>

      <div style={{marginBottom:6}}>
        {inv.lineas.map((l,i)=>{
          const g=groups.find(g=>g.id===l.groupId);
          return(
            <div key={l.id} style={{marginBottom:10,background:"#111e14",borderRadius:12,padding:"12px 14px",border:`1px solid ${g?.color||"#1a2e1a"}55`,transition:"border-color 0.3s"}}>
              <div style={{marginBottom:10}}>
                <NombreInput
                  value={l.nombre}
                  lineaId={l.id}
                  groups={groups}
                  onCommit={val=>setL(i,"nombre",val)}
                  onGroupDetected={handleGroupDetected}
                />
              </div>
              <div style={{display:"grid",gridTemplateColumns:"80px 70px 100px 110px 1fr 28px",gap:8,alignItems:"end"}}>
                <div>
                  <div style={{fontSize:10,color:"rgba(232,240,232,0.3)",textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>Cant.</div>
                  <input type="number" value={l.cantidad} onChange={e=>{
                    const cant=e.target.value;
                    const imp=Math.round((Number(cant)||0)*(Number(l.precioUnit)||0)*100)/100;
                    setInv(p=>({...p,lineas:p.lineas.map((x,idx)=>idx===i?{...x,cantidad:cant,importe:imp}:x)}));
                  }} style={{...IS,fontSize:13}}/>
                </div>
                <div>
                  <div style={{fontSize:10,color:"rgba(232,240,232,0.3)",textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>Unid.</div>
                  <input value={l.unidad} onChange={e=>setL(i,"unidad",e.target.value)} style={{...IS,fontSize:13}}/>
                </div>
                <div>
                  <div style={{fontSize:10,color:"rgba(232,240,232,0.3)",textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>P.Unit.</div>
                  <input type="number" step="0.01" value={l.precioUnit} onChange={e=>{
                    const precio=e.target.value;
                    const imp=Math.round((Number(l.cantidad)||0)*(Number(precio)||0)*100)/100;
                    setInv(p=>({...p,lineas:p.lineas.map((x,idx)=>idx===i?{...x,precioUnit:precio,importe:imp}:x)}));
                  }} style={{...IS,fontSize:13}}/>
                </div>
                <div>
                  <div style={{fontSize:10,color:"rgba(232,240,232,0.3)",textTransform:"uppercase",letterSpacing:1,marginBottom:4,color:"#7bc47b"}}>Importe ✓</div>
                  <input type="number" step="0.01" value={l.importe} readOnly style={{...IS,fontSize:13,color:"#7bc47b",fontWeight:700,opacity:0.9}}/>
                </div>
                <div>
                  <div style={{fontSize:10,color:"rgba(232,240,232,0.3)",textTransform:"uppercase",letterSpacing:1,marginBottom:4}}>Grupo</div>
                  <select value={l.groupId} onChange={e=>setL(i,"groupId",e.target.value)} style={{...IS,fontSize:13,background:`${g?.color||"#1a2e1a"}22`,border:`1px solid ${g?.color||"rgba(255,255,255,0.08)"}77`}}>
                    {groups.map(g=><option key={g.id} value={g.id}>{g.icon} {g.name}</option>)}
                  </select>
                </div>
                <button onClick={()=>remL(i)} style={{background:"none",border:"none",color:"rgba(232,240,232,0.25)",cursor:"pointer",fontSize:20,padding:0,marginBottom:2,alignSelf:"end"}}>×</button>
              </div>
            </div>
          );
        })}
      </div>
      <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:22}}>
        <button onClick={addL} style={{...BS,fontSize:12,padding:"7px 14px"}}>+ Añadir producto</button>
        <span style={{fontSize:11,color:"rgba(232,240,232,0.28)"}}>⚡ El grupo se detecta automáticamente al escribir</span>
      </div>

      <div style={{display:"flex",gap:10}}>
        <button onClick={onBack} style={BS}>Volver</button>
        <button onClick={onSave} disabled={!inv.proveedor||inv.lineas.every(l=>!l.nombre)} style={BP}>Guardar y actualizar stock</button>
      </div>
    </div>
  );
}


// ─── RESUMEN VIEW ─────────────────────────────────────────────────────────────
function ResumenView({groups,facturas,monthStock,month,year}){
  const [open,setOpen]=useState(null);
  const total=facturas.reduce((s,f)=>s+f.total,0);

  return(
    <div>
      <h1 style={H1}>Resumen — {MONTHS[month]} {year}</h1>
      <div style={{background:"rgba(123,196,123,0.06)",border:"1px solid rgba(123,196,123,0.14)",borderRadius:16,padding:"22px 26px",marginBottom:28}}>
        <div style={{fontSize:11,letterSpacing:2,textTransform:"uppercase",color:"rgba(232,240,232,0.3)",marginBottom:6}}>Gasto total del mes</div>
        <div style={{fontFamily:"'Playfair Display',Georgia,serif",fontSize:40,color:"#7bc47b"}}>{euro(total)}</div>
        <div style={{fontSize:13,color:"rgba(232,240,232,0.32)",marginTop:6}}>{facturas.length} facturas · {new Set(facturas.map(f=>f.proveedor)).size} proveedores</div>
      </div>

      {groups.map(g=>{
        const gProds=monthStock[g.id]||{};
        const gTotal=Object.values(gProds).reduce((s,p)=>s+p.totalGasto,0);
        // facturas que tienen al menos una línea de este grupo
        const gFacturas=facturas.filter(f=>f.lineas.some(l=>l.groupId===g.id));
        if(!Object.keys(gProds).length) return null;
        const isOpen=open===g.id;

        return(
          <div key={g.id} style={{marginBottom:12}}>
            <div onClick={()=>setOpen(isOpen?null:g.id)} style={{
              background:"#111e14",border:`1px solid ${isOpen?(g.color||"#7bc47b")+"55":"#1a2e1a"}`,
              borderRadius:isOpen?"12px 12px 0 0":12,padding:"14px 18px",cursor:"pointer",
              display:"flex",alignItems:"center",gap:14,
            }}>
              <span style={{fontSize:22}}>{g.icon}</span>
              <div style={{flex:1}}>
                <div style={{fontWeight:700,fontSize:15}}>{g.name}</div>
                <div style={{fontSize:12,color:"rgba(232,240,232,0.35)",marginTop:3}}>{Object.keys(gProds).length} producto{Object.keys(gProds).length!==1?"s":""}</div>
              </div>
              <div style={{color:g.color||"#7bc47b",fontWeight:700,fontSize:17}}>{euro(gTotal)}</div>
              <span style={{color:"rgba(232,240,232,0.2)",fontSize:11}}>{isOpen?"▲":"▼"}</span>
            </div>

            {isOpen&&(
              <div style={{background:"rgba(0,0,0,0.18)",border:`1px solid ${g.color||"#7bc47b"}22`,borderTop:"none",borderRadius:"0 0 12px 12px",padding:"16px 18px"}}>
                {/* Products */}
                <div style={{marginBottom:18}}>
                  <div style={{fontSize:11,textTransform:"uppercase",letterSpacing:1,color:"rgba(232,240,232,0.28)",marginBottom:10}}>Productos</div>
                  <div style={{display:"grid",gap:6}}>
                    {Object.entries(gProds).map(([name,p])=>(
                      <div key={name} style={{background:"rgba(255,255,255,0.03)",borderRadius:8,padding:"10px 14px",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:10}}>
                        <span style={{fontWeight:600,fontSize:14}}>{name}</span>
                        <div style={{display:"flex",gap:20}}>
                          <SStat label="Cantidad" value={`${Number(p.totalQty.toFixed(3))} ${p.unidad}`} color="#7bc47b"/>
                          <SStat label="Gastado" value={euro(p.totalGasto)} color={g.color||"#C8854A"}/>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                {/* Invoices with lines of this group */}
                <div style={{fontSize:11,textTransform:"uppercase",letterSpacing:1,color:"rgba(232,240,232,0.28)",marginBottom:10}}>Facturas</div>
                {gFacturas.map((f,fi)=>{
                  const gLines=f.lineas.filter(l=>l.groupId===g.id);
                  return(
                    <div key={fi} style={{marginBottom:10,background:"rgba(0,0,0,0.15)",borderRadius:8,padding:"10px 14px",border:"1px solid rgba(255,255,255,0.04)"}}>
                      <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
                        <span style={{fontSize:13,color:"rgba(232,240,232,0.55)"}}>🏢 {f.proveedor} · {f.fecha}{f.numero_factura?` · Nº ${f.numero_factura}`:""}</span>
                        <span style={{color:g.color||"#7bc47b",fontWeight:700}}>{euro(gLines.reduce((s,l)=>s+Number(l.importe),0))}</span>
                      </div>
                      <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
                        <thead><tr style={{color:"rgba(232,240,232,0.28)"}}>
                          <th style={{textAlign:"left",fontWeight:"normal",paddingBottom:4}}>Producto</th>
                          <th style={{textAlign:"right",fontWeight:"normal",paddingBottom:4}}>Cant.</th>
                          <th style={{textAlign:"right",fontWeight:"normal",paddingBottom:4}}>P.Unit.</th>
                          <th style={{textAlign:"right",fontWeight:"normal",paddingBottom:4}}>Importe</th>
                        </tr></thead>
                        <tbody>{gLines.map((l,li)=>(
                          <tr key={li} style={{borderTop:"1px solid rgba(255,255,255,0.04)"}}>
                            <td style={{padding:"3px 0"}}>{l.nombre}</td>
                            <td style={{textAlign:"right",color:"rgba(232,240,232,0.48)"}}>{l.cantidad} {l.unidad}</td>
                            <td style={{textAlign:"right",color:"rgba(232,240,232,0.48)"}}>{euro(l.precioUnit)}</td>
                            <td style={{textAlign:"right",color:g.color||"#7bc47b"}}>{euro(l.importe)}</td>
                          </tr>
                        ))}</tbody>
                      </table>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
      {facturas.length===0&&<Empty text="Sin datos para este mes"/>}
    </div>
  );
}

// ─── GRUPOS VIEW ──────────────────────────────────────────────────────────────
function GruposView({groups,setGroups,lineas}){
  const [showNew,setShowNew]=useState(false);
  const [ng,setNg]=useState({name:"",icon:"🏷️",color:"#888"});
  return(
    <div>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:24,flexWrap:"wrap",gap:12}}>
        <h1 style={H1}>Grupos de Gasto</h1>
        <button onClick={()=>setShowNew(!showNew)} style={BP}>+ Nuevo grupo</button>
      </div>
      {showNew&&(
        <div style={{background:"#111e14",border:"1px solid rgba(123,196,123,0.2)",borderRadius:12,padding:18,marginBottom:20}}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 80px 120px",gap:12,marginBottom:12}}>
            <input placeholder="Nombre" value={ng.name} onChange={e=>setNg(p=>({...p,name:e.target.value}))} style={IS}/>
            <input placeholder="🏷️" value={ng.icon} onChange={e=>setNg(p=>({...p,icon:e.target.value}))} style={{...IS,textAlign:"center",fontSize:20}}/>
            <input type="color" value={ng.color} onChange={e=>setNg(p=>({...p,color:e.target.value}))} style={{...IS,padding:4,cursor:"pointer"}}/>
          </div>
          <div style={{display:"flex",gap:10}}>
            <button disabled={!ng.name.trim()} onClick={()=>{setGroups(p=>[...p,{...ng,id:uid()}]);setNg({name:"",icon:"🏷️",color:"#888"});setShowNew(false);}} style={BP}>Guardar</button>
            <button onClick={()=>setShowNew(false)} style={BS}>Cancelar</button>
          </div>
        </div>
      )}
      <div style={{display:"grid",gap:10}}>
        {groups.map(g=>(
          <div key={g.id} style={{background:"#111e14",border:"1px solid #1a2e1a",borderRadius:12,padding:"14px 18px",display:"flex",alignItems:"center",gap:14}}>
            <span style={{fontSize:26}}>{g.icon}</span>
            <div style={{flex:1}}>
              <div style={{fontWeight:700}}>{g.name}</div>
              <div style={{fontSize:12,color:"rgba(232,240,232,0.28)",marginTop:3}}>{lineas.filter(l=>l.groupId===g.id).length} líneas de producto registradas</div>
            </div>
            <div style={{width:22,height:22,borderRadius:"50%",background:g.color||"#888"}}/>
            {!INITIAL_GROUPS.find(ig=>ig.id===g.id)&&(
              <button className="delbtn" onClick={()=>{if(confirm("¿Eliminar?"))setGroups(p=>p.filter(x=>x.id!==g.id));}} style={{background:"none",border:"none",color:"rgba(232,240,232,0.18)",cursor:"pointer",fontSize:18,transition:"color 0.15s"}}>🗑</button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Shared tiny components ───────────────────────────────────────────────────
function SStat({label,value,color}){
  return(
    <div>
      <div style={{fontSize:10,color:"rgba(232,240,232,0.3)",textTransform:"uppercase",letterSpacing:1,marginBottom:2}}>{label}</div>
      <div style={{fontSize:14,color,fontWeight:700}}>{value}</div>
    </div>
  );
}
function Empty({text}){return <div style={{textAlign:"center",padding:"60px 20px",color:"rgba(232,240,232,0.22)"}}><div style={{fontSize:44,marginBottom:10}}>📭</div><div>{text}</div></div>;}

// ─── Texto Paste ─────────────────────────────────────────────────────────────
function TextoPaste({ groups, aiLoading, setAiLoading, aiError, setAiError, onResult, onBack }) {
  const [texto, setTexto] = useState("");

  async function analizar() {
    if (!texto.trim()) return;
    setAiLoading(true); setAiError("");
    try {
      const groupList = groups.map(g => `"${g.id}": ${g.name}`).join(", ");
      const resp = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST", headers: { "Content-Type": "application/json", "x-api-key": process.env.REACT_APP_ANTHROPIC_KEY, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514", max_tokens: 2000,
          messages: [{ role: "user", content: `Analiza este texto de una factura o ticket de compra y extrae los datos. Responde SOLO con JSON sin markdown:
{
  "proveedor": "nombre del establecimiento o empresa",
  "fecha": "YYYY-MM-DD o null si no aparece",
  "numero_factura": "número o null",
  "lineas": [
    {
      "nombre": "nombre del producto",
      "cantidad": número,
      "unidad": "kg|L|ud|caja|botella|sobre|paquete|etc",
      "precioUnit": número,
      "importe": número,
      "groupId": "el id más adecuado de esta lista: ${groupList}"
    }
  ]
}

Texto de la factura:
${texto}` }]
        })
      });
      const data = await resp.json();
      const raw = data.content.map(i => i.text || "").join("");
      const parsed = JSON.parse(raw.replace(/\`\`\`json|\`\`\`/g, "").trim());
      const lineas = parsed.lineas.map(l => ({
        ...l,
        id: Math.random().toString(36).substr(2,9),
        proveedor: parsed.proveedor || "",
        fecha: parsed.fecha || new Date().toISOString().split("T")[0],
        numero_factura: parsed.numero_factura || "",
        groupId: groups.find(g => g.id === l.groupId) ? l.groupId : "otros",
      }));
      onResult({
        id: Math.random().toString(36).substr(2,9),
        proveedor: parsed.proveedor || "",
        fecha: parsed.fecha || new Date().toISOString().split("T")[0],
        numero_factura: parsed.numero_factura || "",
        total: lineas.reduce((s, l) => s + Number(l.importe), 0),
        lineas,
        origen: "texto",
      });
    } catch(e) {
      setAiError("No se pudo interpretar el texto. Revisa que esté bien copiado.");
    }
    setAiLoading(false);
  }

  return (
    <div style={{ maxWidth: 520 }}>
      <div style={{ background:"rgba(123,196,123,0.07)", border:"1px solid rgba(123,196,123,0.2)", borderRadius:10, padding:"12px 16px", marginBottom:18, fontSize:13, color:"rgba(232,240,232,0.6)", lineHeight:1.7 }}>
        <strong style={{color:"#7bc47b"}}>Cómo usarlo en iPhone:</strong><br/>
        1. Abre la foto del ticket en Fotos<br/>
        2. Pulsa el icono de <strong>Live Text</strong> (esquina inferior derecha)<br/>
        3. Pulsa <strong>Seleccionar todo → Copiar</strong><br/>
        4. Pega aquí abajo y pulsa Analizar
      </div>
      <div style={{ marginBottom:14 }}>
        <label style={LB}>Texto de la factura o ticket</label>
        <textarea
          value={texto}
          onChange={e => setTexto(e.target.value)}
          placeholder={"Pega aquí el texto copiado del ticket...

Ejemplo:
Mercadona
Café molido 500g  2ud  3,45€
Leche entera 1L  6ud  5,90€
Total: 9,35€"}
          style={{ width:"100%", minHeight:220, background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.15)", color:"#e8f0e8", padding:"12px 14px", borderRadius:10, fontFamily:"inherit", fontSize:14, resize:"vertical", outline:"none", lineHeight:1.6 }}
        />
      </div>
      {aiError && <div style={{ color:"#e07070", fontSize:13, marginBottom:14, background:"rgba(200,60,60,0.1)", border:"1px solid rgba(200,60,60,0.3)", borderRadius:8, padding:"10px 14px" }}>{aiError}</div>}
      <div style={{ display:"flex", gap:10 }}>
        <button onClick={onBack} style={BS}>← Volver</button>
        <button onClick={analizar} disabled={!texto.trim() || aiLoading} style={{ ...BP, flex:1 }}>
          {aiLoading ? "⏳ Analizando…" : "✨ Analizar con IA"}
        </button>
      </div>
    </div>
  );
}

// ─── Camera Capture ──────────────────────────────────────────────────────────
function CameraCapture({ onCapture, onBack, aiLoading }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [stream, setStream] = useState(null);
  const [error, setError] = useState("");
  const [captured, setCaptured] = useState(null); // blob URL preview
  const [capturedBlob, setCapturedBlob] = useState(null);

  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, []);

  async function startCamera() {
    setError("");
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: "environment" }, width: { ideal: 1920 }, height: { ideal: 1080 } }
      });
      setStream(s);
      if (videoRef.current) {
        videoRef.current.srcObject = s;
        videoRef.current.play();
      }
    } catch (e) {
      setError("No se pudo acceder a la cámara. Asegúrate de dar permiso o usa la opción de galería.");
    }
  }

  function stopCamera() {
    if (stream) stream.getTracks().forEach(t => t.stop());
  }

  function capture() {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    canvas.width  = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext("2d").drawImage(video, 0, 0);
    canvas.toBlob(blob => {
      if (!blob) return;
      setCapturedBlob(blob);
      setCaptured(URL.createObjectURL(blob));
      stopCamera();
    }, "image/jpeg", 0.92);
  }

  function retry() {
    setCaptured(null);
    setCapturedBlob(null);
    startCamera();
  }

  function confirm() {
    if (!capturedBlob) return;
    const file = new File([capturedBlob], "captura.jpg", { type: "image/jpeg" });
    onCapture(file);
  }

  return (
    <div style={{ maxWidth: 500 }}>
      <canvas ref={canvasRef} style={{ display: "none" }} />

      {!captured ? (
        <>
          {/* Viewfinder */}
          <div style={{ position: "relative", borderRadius: 14, overflow: "hidden", background: "#000", marginBottom: 16, border: "2px solid rgba(123,196,123,0.3)" }}>
            <video ref={videoRef} autoPlay playsInline muted style={{ width: "100%", display: "block", maxHeight: 360, objectFit: "cover" }} />
            {/* Corner guides */}
            {[{top:10,left:10},{top:10,right:10},{bottom:10,left:10},{bottom:10,right:10}].map((pos,i)=>(
              <div key={i} style={{ position:"absolute", ...pos, width:28, height:28,
                borderTop: (pos.top!==undefined) ? "3px solid #7bc47b" : "none",
                borderBottom: (pos.bottom!==undefined) ? "3px solid #7bc47b" : "none",
                borderLeft: (pos.left!==undefined) ? "3px solid #7bc47b" : "none",
                borderRight: (pos.right!==undefined) ? "3px solid #7bc47b" : "none",
              }}/>
            ))}
            <div style={{ position:"absolute", bottom:12, left:0, right:0, textAlign:"center", fontSize:12, color:"rgba(255,255,255,0.5)" }}>
              Apunta a la factura o ticket
            </div>
          </div>
          {error && <div style={{ color:"#e07070", fontSize:13, marginBottom:14, background:"rgba(200,60,60,0.1)", border:"1px solid rgba(200,60,60,0.3)", borderRadius:8, padding:"10px 14px" }}>{error}</div>}
          <div style={{ display:"flex", gap:10 }}>
            <button onClick={onBack} style={BS}>← Volver</button>
            {!error && <button onClick={capture} style={{ ...BP, flex:1, fontSize:16 }}>📸 Capturar</button>}
          </div>
        </>
      ) : (
        <>
          {/* Preview */}
          <div style={{ borderRadius:14, overflow:"hidden", marginBottom:16, border:"2px solid rgba(123,196,123,0.4)" }}>
            <img src={captured} alt="captura" style={{ width:"100%", display:"block", maxHeight:360, objectFit:"cover" }}/>
          </div>
          <p style={{ fontSize:13, color:"rgba(232,240,232,0.5)", marginBottom:16 }}>¿Se ve bien la factura? Si sí, pulsa Analizar.</p>
          <div style={{ display:"flex", gap:10 }}>
            <button onClick={retry} style={BS}>🔄 Repetir</button>
            <button onClick={confirm} disabled={aiLoading} style={{ ...BP, flex:1 }}>
              {aiLoading ? "⏳ Analizando…" : "🔍 Analizar con IA"}
            </button>
          </div>
        </>
      )}
    </div>
  );
}

// ─── Shared styles ────────────────────────────────────────────────────────────
const H1={fontFamily:"'Playfair Display',Georgia,serif",fontSize:26,color:"#7bc47b",fontWeight:400,margin:"0 0 4px"};
const BP={background:"linear-gradient(135deg,#3a7a3a,#2a5a2a)",color:"#e8f0e8",border:"none",padding:"10px 20px",borderRadius:8,cursor:"pointer",fontFamily:"inherit",fontSize:14,fontWeight:700};
const BS={background:"rgba(255,255,255,0.04)",color:"rgba(232,240,232,0.55)",border:"1px solid rgba(255,255,255,0.08)",padding:"10px 16px",borderRadius:8,cursor:"pointer",fontFamily:"inherit",fontSize:14};
const IS={width:"100%",background:"rgba(0,0,0,0.32)",border:"1px solid rgba(255,255,255,0.08)",color:"#e8f0e8",padding:"9px 12px",borderRadius:8,fontFamily:"inherit",fontSize:14};
const SS={background:"rgba(0,0,0,0.4)",border:"1px solid rgba(123,196,123,0.2)",color:"#e8f0e8",padding:"7px 12px",borderRadius:8,fontFamily:"inherit",fontSize:13};
const LB={display:"block",fontSize:11,color:"rgba(232,240,232,0.38)",marginBottom:6,textTransform:"uppercase",letterSpacing:1};
