# Gestión Cafetería

## Instalación

```bash
npm install
```

## Configuración

1. Copia `.env.example` a `.env`
2. Añade tu clave API de Anthropic:
   ```
   REACT_APP_ANTHROPIC_KEY=sk-ant-...
   ```

## Desarrollo local

```bash
npm start
```

## Despliegue en Netlify

1. Sube esta carpeta a GitHub
2. Conecta el repo en netlify.com
3. Añade la variable de entorno `REACT_APP_ANTHROPIC_KEY` en Netlify → Site settings → Environment variables
4. Deploy automático

## Con Claude Code

```bash
# Instalar Claude Code
npm install -g @anthropic-ai/claude-code

# Abrir en la carpeta del proyecto
cd cafeteria-app
claude
```
